#xchanger

This program provides a middleman that will listen out for messages on RabbitMQ and then send them to a service via HTTPS.
 