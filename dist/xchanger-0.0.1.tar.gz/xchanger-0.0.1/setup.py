import setuptools

setuptools.setup()